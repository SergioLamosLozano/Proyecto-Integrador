// Web implementation of SpeechService using the browser Web Speech API
// via JS interop (dart:js_util and dart:js). This file is only included when
// building for web (conditional import from `speech.dart`).

import 'dart:async';
import 'dart:html' as html;
import 'dart:js' show allowInterop;
import 'dart:js_util' as js_util;
import 'speech.dart';

class SpeechServiceImpl implements SpeechService {
  dynamic _recognition;
  bool _listening = false;
  bool _userStopped = false;
  Timer? _silenceTimer;
  Duration _silenceThreshold = Duration(milliseconds: 5000);

  // store callbacks so we can restart transparently on short pauses
  void Function(String text, bool isFinal)? _onResult;
  void Function()? _onDone;
  String _locale = 'es-ES';

  dynamic _getCtor() {
    return js_util.getProperty(html.window, 'SpeechRecognition') ?? js_util.getProperty(html.window, 'webkitSpeechRecognition');
  }

  void _clearTimer() {
    try {
      _silenceTimer?.cancel();
    } catch (e) {}
    _silenceTimer = null;
  }

  void _startSilenceTimer() {
    _clearTimer();
    _silenceTimer = Timer(_silenceThreshold, () {
      // consider this the end of a user's speech — stop recognition and notify
      try {
        stopListening();
      } catch (e) {}
      try {
        _onDone?.call();
      } catch (e) {}
    });
  }

  @override
  Future<void> startListening({String locale = 'es-ES', required void Function(String text, bool isFinal) onResult, void Function()? onDone}) async {
    // If already listening, don't start another session.
    if (_listening) return;

    _onResult = onResult;
    _onDone = onDone;
    _locale = locale;
    _userStopped = false;

    final ctor = _getCtor();
    if (ctor == null) {
      // Not supported
      onDone?.call();
      return;
    }

    try {
      _recognition = js_util.callConstructor(ctor, []);

      js_util.setProperty(_recognition, 'lang', _locale);
      js_util.setProperty(_recognition, 'interimResults', true);
      // request continuous so short pauses don't cause immediate end
      js_util.setProperty(_recognition, 'continuous', true);

      js_util.setProperty(_recognition, 'onresult', allowInterop((event) {
        try {
          // aggregate all results into a best transcript
          final results = js_util.getProperty(event, 'results');
          final int resultsLen = js_util.getProperty(results, 'length') as int? ?? 0;
          StringBuffer buf = StringBuffer();
          bool finalFlag = false;
          for (var i = 0; i < resultsLen; i++) {
            final item = js_util.getProperty(results, i);
            final alt = js_util.getProperty(item, 0);
            final transcript = js_util.getProperty(alt, 'transcript') as String? ?? '';
            final isFinal = js_util.getProperty(item, 'isFinal') as bool? ?? false;
            if (transcript.isNotEmpty) {
              buf.write(transcript);
            }
            if (isFinal) finalFlag = true;
          }
          final text = buf.toString();
          // reset silence timer so short pauses won't stop us
          _startSilenceTimer();
          _onResult?.call(text, finalFlag);
        } catch (e) {
          // ignore parse errors
        }
      }));

      js_util.setProperty(_recognition, 'onend', allowInterop((_) async {
        _listening = false;
        _clearTimer();
        // If the user didn't request a stop, the browser may have ended the session
        // after a short pause; in that case, try to restart to maintain continuity.
        if (!_userStopped) {
          // small delay before restart to avoid tight loops
          await Future.delayed(Duration(milliseconds: 300));
          try {
            // restart recognition to continue listening
            if (!_userStopped) {
              await startListening(locale: _locale, onResult: _onResult!, onDone: _onDone);
            }
          } catch (e) {
            // give up and notify done
            try {
              _onDone?.call();
            } catch (e) {}
          }
        } else {
          // normal user-initiated stop
          try {
            _onDone?.call();
          } catch (e) {}
        }
      }));

      // start recognition
      js_util.callMethod(_recognition, 'start', []);
      _listening = true;
      // Start silence timer in case no results come
      _startSilenceTimer();
    } catch (e) {
      _listening = false;
      _clearTimer();
      onDone?.call();
    }
  }

  @override
  void stopListening() {
    _userStopped = true;
    try {
      if (_recognition != null) {
        js_util.callMethod(_recognition, 'stop', []);
      }
    } catch (e) {
      // ignore
    }
    _clearTimer();
    _listening = false;
  }

  @override
  bool get isListening => _listening;
}
