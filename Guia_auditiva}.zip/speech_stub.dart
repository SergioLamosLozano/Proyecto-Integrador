import 'speech.dart';

/// Fallback stub implementation when not on web. Does nothing.
class SpeechServiceImpl implements SpeechService {
  bool _listening = false;

  @override
  Future<void> startListening({String locale = 'es-ES', required void Function(String text, bool isFinal) onResult, void Function()? onDone}) async {
    // No-op on platforms without web Speech API.
    _listening = false;
    onDone?.call();
  }

  @override
  void stopListening() {
    _listening = false;
  }

  @override
  bool get isListening => _listening;
}
