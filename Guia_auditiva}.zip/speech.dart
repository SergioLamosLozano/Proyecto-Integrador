// Conditional import: use web implementation when building for web.
import 'speech_stub.dart' if (dart.library.html) 'speech_web.dart';

// Public speech service interface and loader. The conditional import above
// must provide a concrete `SpeechServiceImpl` class implementing this API.
abstract class SpeechService {
  /// Start listening. Calls [onResult] repeatedly with interim/final results.
  Future<void> startListening({String locale = 'es-ES', required void Function(String text, bool isFinal) onResult, void Function()? onDone});

  /// Stop current listening session if any.
  void stopListening();

  /// Whether the service is currently listening.
  bool get isListening;
}

// The web or stub file must provide `SpeechServiceImpl` class that implements SpeechService.
final SpeechService speech = SpeechServiceImpl();
